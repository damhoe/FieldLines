package com.damhoe.fieldlines;

/**
 * Created by damian on 08.12.2017.
 */

import android.content.Context;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class OpenFile {

//    ChargeList getCharges(Context context){
//
//        String filename = "myfile";
//        String string = "Hello world!";
//        FileInputStream inputStream;
//        String chargeString = "";
//
//        try {
//            File myFile = new File(context.getFilesDir(),"savegame.txt");
//            myFile.createNewFile();
//            inputStream = context.openFileInput("savegame.txt");
////            FileOutputStream fOut = new FileOutputStream(myFile);
//            chargeString += inputStream.read();
////            myOutWriter.append("2");
////            myOutWriter.close();
////            fOut.close();
//            Toast.makeText(context,"You have opened a file!",
//                    Toast.LENGTH_SHORT).show();
//        } catch (Exception e) {
//            Toast.makeText(context, e.getMessage(),
//                    Toast.LENGTH_SHORT).show();
//        }
//
//        return getChargeList(chargeString);
//    }
//
//    private ChargeList getChargeList(String chargeString) {
//        ChargeList list = new ChargeList();
//        return list;
//    }
//
//    private String getChargeStringList(ChargeList charges) {
//        String g = "Hallo";
//        return g;
//    }
}
/**
 * Created by damian on 08.12.2017.
 */

