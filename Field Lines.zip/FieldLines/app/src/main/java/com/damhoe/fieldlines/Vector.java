package com.damhoe.fieldlines;

/**
 * Created by damian on 02.12.2017.
 */
public class Vector {
    double xValue;
    double yValue;

    Vector (double xValue, double yValue){
        this.xValue = xValue;
        this.yValue = yValue;
    }
}
