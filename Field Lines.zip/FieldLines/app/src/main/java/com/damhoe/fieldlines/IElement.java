package com.damhoe.fieldlines;

/**
 * Created by shoedtke on 09.12.2017.
 */

public interface IElement {
    String getName();
    String getValue();
}
